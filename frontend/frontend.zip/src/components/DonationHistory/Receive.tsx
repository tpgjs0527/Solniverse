function Receive() {
  return <div>Receive</div>;
}

export default Receive;
